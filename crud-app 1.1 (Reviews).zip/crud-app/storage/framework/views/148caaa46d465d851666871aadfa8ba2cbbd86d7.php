<!-- 
* Similar to "Create()" page, w/ a few tweaks. ;)

* "Forms.blade" ==> Has the "Repeated Form" stuff. ;)

  -->



<?php $__env->startSection('content'); ?>
<div class="column col-3">
  <h3>Edit a Product</h3>


  <form method="POST" action="<?php echo e(route('products.update', $product->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="form-group">
      <?php echo $__env->make('products.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="form-group">
      <button type="submit" class="btn btn-primary">Update Product</button>
      <a class="btn btn-danger" href="<?php echo e(route('products.index')); ?>">Cancel</a>
    </div>
  </form>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/products/edit.blade.php ENDPATH**/ ?>