<!-- 
* Bootstrap for "Form"

* Allow input of "Non-auto generated items" (ie: NO date / ID needed. ;) )

* Send to "New Info" to "store" ie: <form method="POST" action="<?php echo e(route('products.store')); ?>">

* Link "Cancel" button to index.blade ;)

* Validate via "@crsf" (here); Actual validation done in Controller.store().

* 

  -->



<?php $__env->startSection('content'); ?>
<div class="column col-3">
  <h3>Add a Product</h3>


  <form method="POST" action="<?php echo e(route('products.store')); ?>">
    <?php echo csrf_field(); ?>

    <div class="form-group">
      <?php echo $__env->make('products.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="form-group">
      <button type="submit" class="btn btn-primary">Add Product</button>
      <a href="<?php echo e(route('products.index')); ?>" class="btn btn-danger">Cancel</a>
    </div>
  </form>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/products/create.blade.php ENDPATH**/ ?>