<!--
   * Reformat for "Single Product" (found at: /product/<id>, ie. /products/35)

   * Show full/mid size image for product

   * Show all data for a product (ie: forEach Products as Product)

   * Link back to "All Products" page (shown below)
<h5> <a href="<?php echo e(route('products.index', $product->id)); ?>"><?php echo e($product->name); ?></h5>

 * Bootstrap moved to "view/layout.blade.php"
      
 * format "price" in code
-->




<?php $__env->startSection('content'); ?>
<h1>Product Detail</h1>

<div class="container mt-5">
  <table class="table table-bordered mb-5">
    <thead>
      <tr class="table-success">
        <th scope="col">#</th>
        <th scope="col">Product name</th>
        <th scope="col">Price</th>
        <th scope="col">Description</th>
        <th scope="col">Item Number</th>
        <th scope="col">Image</th>
      </tr>
    </thead>
    <tbody>

      <tr>
        <th scope="row"><?php echo e($product->id); ?></th>
        <td><?php echo e($product->name); ?></td>
        <td>$<?php echo e(number_format($product->price, 2)); ?></td>
        <td><?php echo e($product->description); ?></td>
        <td><?php echo e($product->item_number); ?></td>
        <td><img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->image); ?>" class="img-thumbnail"></td>
        <td>
          <h5> <a href="<?php echo e(route('products.index')); ?>">All Products</h5>
        </td>
      </tr>
    </tbody>
  </table>
</div>


<h4 class="fw-bold">
  Reviews:
</h4>



<!-- <label class="form-label" for="rating">Sort by Rating</label>
    <select class="form-select" name="rating">

      <?php $__currentLoopData = range(1,5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ratingOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($ratingOption); ?>"><?php echo e($ratingOption); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select> -->

<div class="column col-3">
  <h3>Add a Review</h3>


  <form method="POST" action="<?php echo e(route('reviews.store')); ?>">
    <?php echo csrf_field(); ?>

</div>
<?php if( $errors->any() ): ?>
<div class="alert alert-danger" role="alert">
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <span><?php echo e($error); ?></span><br />
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>


<div class="container mt-5 form-group">
  <table class="table table-bordered mb-5">
    <label class="form-label" for="comment">Your Comment</label>
    <input type="text" class="form-control" rows="3" name="comment" value="<?php echo e(old('comment')); ?>">

    <label class="form-label" for="rating">Choose Rating</label>
    <select class="form-select" name="rating">

      <?php $__currentLoopData = range(1,5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ratingOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($ratingOption); ?> "><?php echo e($ratingOption); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label class="form-label" for="product_id" hidden>Product ID</label>
    <input type="number" name="product_id" class="form-control" value="<?php echo e($product->id); ?>" hidden />
  </table>
</div>
<div class="form-group">
  <button type="submit" class="btn btn-primary">Add Review</button>
</div>
</form>

<?php if( count($product->reviews) == 0 ): ?>
<div>
  <h2>No reviews yet</h2>
</div>
<?php else: ?>

<div class="container mt-5">
  <!-- <a class="btn btn-primary" href="<?php echo e(route('reviews.store', $product->id)); ?>">Add Review</a> -->

  <table class="table table-bordered mb-5">
    <thead>
      <tr class="table-success">
        <th scope="col">Comment</th>
        <th scope="col">Rating</th>
        <th scope="col">Date Added</th>
        <th></th>
        <th></th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td scope="row"><?php echo e($review->comment); ?></td>


        <td class="text-nowrap"><?php for($i = 0; $i < $review->rating; $i++ ): ?> &#9733 <?php endfor; ?> </td>
        <!-- <?php echo e(str_repeat( "*", $review->rating)); ?> -->

        <td><?php echo e($review->created_at); ?></td>
        <td>
          <form class="btn btn-danger" action="<?php echo e(route('reviews.destroy', $review->id)); ?>" method="POST" onSubmit="return confirm('Are you sure you want to delete?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-error" type="submit">Delete</button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

</div>

<?php endif; ?>



<!-- 
Test page @ item# 752

  * Display a small form to add a review (comment and rating)

     * Has the "n+1" fix here (??)

  * Rating will be acquired by a select list displaying numbers 1-5

  * Below the form will be a list/table of reviews

    * For each row display comment and number of stars the review is.

       * You can use an html entity for star (https://www.toptal.com/designers/htmlarrows/symbols/black-star/https://www.toptal.com/designers/htmlarrows/symbols/black-star/Links to an external site.) or use an image of your choice.

* If no reviews have been given yet, display a message saying "No reviews yet"

* You should be able to delete a review (with JavaScript confirmation)


-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/products/show.blade.php ENDPATH**/ ?>