<?php $__env->startSection('form'); ?>
<div class="column col-3">
  <h3>Add a Review</h3>


  <form method="POST" action="<?php echo e(route('reviews.store')); ?>">
    <?php echo csrf_field(); ?>

</div>
<?php if( $errors->any() ): ?>
<div class="alert alert-danger" role="alert">
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <span><?php echo e($error); ?></span><br />
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>


<div class="container mt-5 form-group">
  <table class="table table-bordered mb-5">
    <label class="form-label" for="comment">Your Comment</label>
    <input type="text" class="form-control" rows="3" name="comment" value="<?php echo e(old('comment', $review->comment)); ?>">

    <label class="form-label" for="rating">Choose Rating</label>
    <select class="form-select" name="rating">

      <?php $__currentLoopData = range(1,5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ratingOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($ratingOption); ?>"><?php echo e($ratingOption); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label class="form-label" for="item_number">Item Number</label>
    <input type="number" name="item_number" class="form-control" value="<?php echo e(old('item_number', $product->item_number)); ?>" />
  </table>
</div>
<div class="form-group">
  <button type="submit" class="btn btn-primary">Add Review</button>
  <a href="<?php echo e(route('products.show')); ?>" class="btn btn-danger">Cancel</a>
</div>
</form>

<?php $__env->stopSection(); ?><?php /**PATH /var/www/html/resources/views/reviews/reviewForm.blade.php ENDPATH**/ ?>