

<?php $__env->startSection('content'); ?>

<div class="container mt-5">
  <a class="btn btn-primary" href="<?php echo e(route('products.create')); ?>">Create Product</a>
  
  <div class="d-flex justify-content-center">
    <?php echo $products->links(); ?>

  </div>

  <table class="table table-bordered mb-5">
    <thead>
      <tr class="table-success">
        <th scope="col">#</th>
        <th scope="col">Product name</th>
        <th scope="col">Price</th>
        <th scope="col">Description</th>
        <th scope="col">Item Number</th>
        <th scope="col">Image</th>
        <th></th>
        <th></th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($product->id); ?></th>
        <td><?php echo e($product->name); ?></td>
        <td>$<?php echo e(number_format($product->price), 2); ?></td>
        <td><?php echo e($product->discription); ?></td>
        <td><?php echo e($product->item_number); ?></td>
        <td><img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->image); ?>" class="img-thumbnail"></td>
        <td><a href="<?php echo e(route('products.show', $product->id)); ?>">Show Detail</a></td>
        <td><a class="btn btn-secondary" href="<?php echo e(route('products.edit', $product->id)); ?>">Edit</a></td>
        <td>
          <form class="btn btn-danger" action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" onSubmit="return confirm('Are you sure you want to delete?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-error" type="submit">Delete</button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>

</div>

<?php $__env->stopSection(); ?>

<!--
  * Reformat page for "All Products" (found at: /products)

  * Use 'thumbnail' for the image

  * Show name, price (formatted as dollar amount), and item_number only

  * Assure the index page paginates the products - 10 per page

  * From the index page, each product's name should be linkable to the show page (<h5> format needs updating ;) )

  * Bootstrap moved to "view/layout.blade.php"

  * Create Button: <a href="<?php echo e(route('products.show', $product->id)); ?>">Show Detail</a>

  * Show Detail link: <a href="<?php echo e(route('products.edit', $product->id)); ?>">Edit Item</a>

  * Edit Button: <a class=bootstrap class href="<?php echo e(route('products.edit', $product->id)); ?>">Edit</a>

  * Delete Button: <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" onSubmit="return confirm('Are you sure you want to delete?');">
                    <?php echo csrf_field(); ?> 
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-error" type="submit">Delete</button>
                  </form>
-->
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/products/index.blade.php ENDPATH**/ ?>