<div class="container mt-5">
  <table class="table table-bordered mb-5">
    <label class="form-label" for="name">Product Name</label>
    <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $product->name)); ?>">

    <label class=" form-label" for="price">Price</label>
    <input step="0.01" type="number" name="price" class="form-control" value="<?php echo e(old('price', $product->price)); ?>" />

    <label for="description">Item Description</label>
    <input class="form-control" name="description" rows="3" value="<?php echo e(old('description', $product->description)); ?>"></input>

    <label class="form-label" for="item_number">Item Number</label>
    <input type="number" name="item_number" class="form-control" value="<?php echo e(old('item_number', $product->item_number)); ?>" />
  </table>
</div><?php /**PATH /var/www/html/resources/views/products/form.blade.php ENDPATH**/ ?>