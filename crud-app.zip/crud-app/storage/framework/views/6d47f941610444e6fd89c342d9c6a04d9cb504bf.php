<!--
   * Reformat for "Single Product" (found at: /product/<id>, ie. /products/35)

   * Show full/mid size image for product

   * Show all data for a product (ie: forEach Products as Product)

   * Link back to "All Products" page (shown below)
<h5> <a href="<?php echo e(route('products.index', $product->id)); ?>"><?php echo e($product->name); ?></h5>

 * Bootstrap moved to "view/layout.blade.php"
      
 * format "price" in code
-->




<?php $__env->startSection('content'); ?>
<h1>Product Detail</h1>

<div class="container mt-5">
  <table class="table table-bordered mb-5">
    <thead>
      <tr class="table-success">
        <th scope="col">#</th>
        <th scope="col">Product name</th>
        <th scope="col">Price</th>
        <th scope="col">Description</th>
        <th scope="col">Item Number</th>
        <th scope="col">Image</th>
      </tr>
    </thead>
    <tbody>

      <tr>
        <th scope="row"><?php echo e($product->id); ?></th>
        <td><?php echo e($product->name); ?></td>
        <td>$<?php echo e(number_format($product->price, 2)); ?></td>
        <td><?php echo e($product->description); ?></td>
        <td><?php echo e($product->item_number); ?></td>
        <td><img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->image); ?>" class="img-thumbnail"></td>
        <td>
          <h5> <a href="<?php echo e(route('products.index', $product->id)); ?>">All Products</h5>
        </td>
      </tr>
    </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/products/show.blade.php ENDPATH**/ ?>